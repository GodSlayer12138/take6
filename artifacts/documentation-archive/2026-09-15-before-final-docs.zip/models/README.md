# 模型保留与归档索引

本目录保存索引，不复制权重。现有模型、冻结配置和审计记录保留原路径。机器清单为 [registry.json](registry.json)，磁盘盘点为 [inventory.json](inventory.json)。截至 2026-09-15，重点管理 10 个条目，共引用 70 个不重复文件；它们包括策略、模型组合、基线和对手池，并非 10 个可互换的独立神经网络。

## 主力与兼容模型

| 保留条目 | 用途 | 保留理由与证据 |
|---|---|---|
| `champion-3p4p-104` → `distill2048-specialist2048` | 三人、四人，104 张，Python/CUDA 搜索 | 最新正式接受版本；胜率 58.36% / 47.79%，相对上一版 +3.27 / +2.54 个百分点。[正式结果](../artifacts/progressive-upgrades/certificate-004/results.json) |
| `specialist-2p-104` → V6 | 二人，104 张，轻量策略 | 胜率 55.66%，相对原模型 +9.18 个百分点；经候选比较校正仍为正。[二人结果](../artifacts/small-player-exploration/classic2-results.json) |
| `browser-legacy` | 其他规则的 `neural_hybrid` 路由及历史对照 | 按需加载；旧 AI 模块静态导入的 30 个 JSON 均列入清单。五人历史主策略配方另见 [ntw-final-v1.json](../artifacts/models/ntw-final-v1.json)。 |

不同评测使用不同牌局、人数和对手池，不能直接相减或合成一个总榜。后续研究继续只关注二至四人。两个主力已接入网页：三四人／104 张使用正式冠军的本机 CUDA 服务，二人／104 张在浏览器使用 V6。默认四人／104 张；实现及启动方式见 [技术报告](../docs/TECHNICAL_REPORT.md)。

### 三四人冠军必须成组保留

冠军入口为 [冻结配置](../artifacts/progressive-upgrades/development-007/distill2048-specialist2048.json)，使用 development-007 中归档的 `progressive_planner.py`，而不是任意替换成当前开发代码。配置记录的依赖共有 10 个 PT 文件：

- `continuation-v2/model.pt`：三人续局网络。
- `ppo-specialist-4-v1/model.pt`：四人续局网络及先验。
- `opponent-proxies-v2/` 下的 `dirv-10000.pt`、`alpha-2000.pt`、`mcs.pt`、`champion-search.pt`：四种对手行为近似网络。
- `artifacts/models/` 下的 `ntw-adaptive5-v1.pt`、`ntw-adaptive-rl-v3b.pt`、`ntw-champion-v2.pt`，以及 `small-player-iterations/v4/model.pt`：冻结运行时依赖。

加上策略配置、归档 planner 和归档环境模块，共 13 个直接文件，逐个路径与 SHA-256 已写入 registry。它不是完整可移植部署包；运行仍依赖仓库的 Python 模块、Node 对局桥接和本机环境。四个对手预测网络也不等同于正式比赛中的真实对手程序。

## 基线与复现保留

| 条目 | 用途 |
|---|---|
| `fast-neural-baseline` → `ntw-adaptive5-v1` | 快速、不做整局搜索的对照；保留 PT 和历史 JSON 导出。名称含 adaptive5 不代表只可用于五人。 |
| `starting-v5` | 三次正式升级的原始起点，保留行排列平均策略。 |
| `accepted-upgrade-1` → `gpu128-proxy` | 第一次接受版本与回归对照，保留全部依赖。 |
| `accepted-upgrade-2` → `proxy-v2-512-lowprior` | 第二次接受版本及当前冠军的直接前版，保留全部依赖。 |
| `frozen-opponent-pool` | 原验收八策略对手池：三个历史神经模型、DirV、Alpha、MCS、冠军搜索、随机策略。具有权重的模型和纯代码策略均保留。 |

完整保留 certificate-001～004 的清单、逐局记录、结果及源码快照，包含未通过的 certificate-003。失败尝试消耗过显著性额度，也是证明三次升级成立所需的记录。对应开发选拔和训练来源记录同样保留。

## 研究保留

新增的 take6 作者权重作为外部评测基线单独保留在 `external/take6/trained-anns/`，来源与摘要见 [provenance.json](../external/take6/provenance.json)，比赛证据保留在 `artifacts/take6-evaluation/`。这两份文件不计入上方原有 registry 的 70 个依赖文件，也未接入网页默认模型。二人专家权重在原生 24 张场景胜过当前网页兼容策略，值得保留作该规则的后续对照；四人权重保留作外部基线。不同场景的具体成绩与限制见 [take6 评测报告](../docs/TAKE6_EVALUATION.md)。

- `opponent-proxies-v3-devshift`：四个已训练并独立审计的第三版对手预测网络，保留选中的 PT、JSON 及训练目录。它们尚未通过新的正式胜率验收。
- `continuation-v3-fourp`：四人强搜索蒸馏网络，保留 PT、JSON 及训练目录。开发对照的胜率区间仍跨零，不能替换已冻结冠军。

`last.pt`、`*-last.pt` 是恢复训练用的检查点，不能因另有 `model.pt` 就一律视作重复。是否保留优化器状态，取决于该分支是否还要继续训练。

## 归档与清理建议

旧 V2/V3/V7、未通过候选、五人历史分支、中间轮次、smoke/profile/pilot 版本不作为新的推荐主力。将它们视为研究档案；其中 V4 仍是冠军的直接依赖，不能整目录删除。

本次盘点实验产物共 **6.95 GB**（十进制），其中明确识别的二进制训练数据约 **4.37 GB**。最大的两项为第二版对手数据集 1.96 GB、第一版对手数据集 1.16 GB。这些文件不参与普通出牌推理，但部分训练来源审计会读取它们。需要腾空间时，优先考虑把训练数据连同协议、生成代码、来源轨迹和校验值做冷备份；恢复训练或对应审计前按原路径还原。

inventory 列出 **387 个待审查的中间／试运行产物**，约 1.06 GB，其中 **159 个已有模型索引或冻结清单引用**。这是按命名规则找到的复核清单，不是可直接删除的清单。静态扫描也无法穷尽动态路径、glob 加载和训练来源依赖。

已有历史 manifest 会固定整个 `artifacts/models/*.json` 集合，甚至包含当时未参赛的模型。因此按“没赢过”批量删除 JSON，会使旧比赛的完整性检查失败。本次完成逻辑分层和入口整理，未移动或删除模型、训练数据及审计证据。可再生成的 `node_modules/`、`dist/`、Python 缓存已加入根目录忽略规则。

## 更新与检查

在仓库根目录执行，使用标准库即可，不加载模型、不启动 GPU：

```powershell
& 'D:/Programs/miniconda3/envs/ntw-ai/python.exe' tools/organize_models.py
& 'D:/Programs/miniconda3/envs/ntw-ai/python.exe' tools/organize_models.py --check
```

第一条仅更新两个索引文件；第二条检查冠军别名、全部索引文件的 SHA-256 和证据入口。它不代替正式比赛审计：

```powershell
& 'D:/Programs/miniconda3/envs/ntw-ai/python.exe' training/audit_progressive_goal.py --require-complete
```
