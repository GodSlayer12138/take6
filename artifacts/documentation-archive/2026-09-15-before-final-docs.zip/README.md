# 牛头王 · AI 牌桌

本地《6 nimmt! / 牛头王》交互游戏与 AI 训练、评测项目。网页支持 2—10 人及 `10n+4`／固定 104 张两种牌池；当前 AI 研究范围为 **2—4 人**。

## 当前模型

| 场景 | 推荐保留 | 已有证据 |
|---|---|---|
| 三人、四人／104 张 | `distill2048-specialist2048` | 三次正式升级已完成；最新验收胜率 58.36%／47.79%，比前版提高 3.27／2.54 个百分点 |
| 二人／104 张 | V6 修正策略 | 独立配对测试胜率 55.66%，比原模型提高 9.18 个百分点，通过比较校正 |
| 其他网页规则 | `neural_hybrid` 及其既有模型路由 | 延续历史功能，不套用二至四人／104 张的专项胜率 |

胜率为第一名份额，并列平分；结论限于各轮指定对手池与规则。三四人冠军使用 Python/CUDA 搜索，平均决策约 0.69／0.80 秒，含并发评测排队时间。不同轮次和人数的胜率不能直接合并排名。

网页默认四人、104 张，实际调用冻结的正式冠军。二人／104 张自动使用 V6；游戏对手、AI 建议和竞技场使用同一路由。冠军需要本机 CUDA 服务，故障会提示重试。

**完整架构、算法、训练、统计结果、接入验证及限制：[详细技术报告](docs/TECHNICAL_REPORT.md)。**

模型入口、依赖及保留建议：[模型索引](models/README.md)。
机器清单：[registry.json](models/registry.json)；存储与归档复核：[inventory.json](models/inventory.json)。

## 运行游戏

```powershell
npm ci
npm run dev  # 同时启动 Python 冠军服务和 Vite，网页默认 http://127.0.0.1:5173
```

```powershell
npm test
npm run build
npm start    # 提供构建后的本机网页，默认 http://127.0.0.1:8765
```

需要 Node.js 和可用的 PyTorch/CUDA Python 环境。启动器默认使用下方本机 Python 路径；其他环境可设置 `NTW_PYTHON`，接口端口可设置 `NTW_API_PORT`。开发模式和生产模式择一运行，避免端口冲突；Ctrl+C 关闭本次启动的配套进程。`npm run dev:web` 仅启动前端，需要另行启动冠军服务。

游戏包含同步暗出、从小到大结算、最低牌选行、牛头计分、玩家视角 AI 建议和批量竞技场。AI 只接收自己的手牌及公开信息。交互竞技场的胜率与 Elo 为演示统计，不计入正式升级。

## 研究与复现

本机训练环境：`D:/Programs/miniconda3/envs/ntw-ai/python.exe`，GPU 为 RTX 4060 Laptop。

```powershell
# 核对推荐模型与依赖文件
& 'D:/Programs/miniconda3/envs/ntw-ai/python.exe' tools/organize_models.py --check

# 回放并独立审计三次正式升级，包含失败尝试
& 'D:/Programs/miniconda3/envs/ntw-ai/python.exe' training/audit_progressive_goal.py --require-complete
```

| 内容 | 文档 |
|---|---|
| 当前完整技术报告与运行说明 | [技术报告](docs/TECHNICAL_REPORT.md) |
| 文档导航 | [文档索引](docs/README.md) |
| 最新三四人胜率与验收记录 | [正式结果](docs/PROGRESSIVE_UPGRADES_RESULTS.md) |
| 选拔、统计门槛、续跑和训练方法 | [连续升级协议](docs/PROGRESSIVE_UPGRADES.md) |
| 二人 V6、V5／V7 探索 | [小人数多路线结果](docs/SMALL_PLAYER_EXPLORATION.md) |
| 本地历史模型比较 | [随机联赛](docs/LOCAL_MODEL_TOURNAMENT.md) |
| Alpha／DirV 方法复现 | [复现说明](docs/ETH_REPRODUCTION.md) · [结果](docs/ETH_REPRODUCTION_RESULTS.md) |
| 外部实现接入边界 | [外部 AI 适配](docs/EXTERNAL_AI_ADAPTER.md) |
| take6 作者预训练权重实测 | [评测报告](docs/TAKE6_EVALUATION.md) |
| 研究范围 | [人数与规则约定](docs/AI_EVALUATION_SCOPE.md) |
| 早期网页 AI、五人实验和 V2—V7 演进 | [历史说明](docs/PROJECT_HISTORY.md) |

## 目录

| 目录 | 用途 |
|---|---|
| `src/web/` | 当前网页模型路由、异步 Worker 和竞技场调度 |
| `src/game/` | 游戏规则与历史 AI；保持冻结评测依赖 |
| `server/` | 正式冠军 HTTP 服务、输入边界测试与归档一致性验证 |
| `models/` | 推荐模型索引、保留策略和存储清单；不重复存放权重 |
| `training/` | Python 训练、搜索、比赛、审计和后台监督 |
| `scripts/` | Node 评测、数据生成与推理桥接 |
| `tools/` | 模型导出、索引维护工具 |
| `tests/` | JavaScript 规则及 AI 测试 |
| `artifacts/` | 模型权重、冻结配置、训练数据与评测证据 |
| `docs/` | 协议、实验结果与历史说明 |
| `external/` | 外部参考实现 |

模型与历史清单包含固定路径和 SHA-256。整理归档前先检查依赖；模型索引仅提供逻辑别名，不改变冻结路径。训练数据、未通过实验和中间检查点的处理建议见 [保留与归档策略](models/README.md)。
