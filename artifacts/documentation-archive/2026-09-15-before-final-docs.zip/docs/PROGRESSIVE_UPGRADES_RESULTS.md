# 三人、四人连续升级：当前进度

更新时间：2026-09-13T11:28:25+08:00

**已验收通过 3 / 3 次连续升级。** 当前接受基线：`distill2048-specialist2048`。

开发胜率、对手预测准确率、训练收益以及版本号均不计入升级次数。验收规则见 [实验说明](PROGRESSIVE_UPGRADES.md)。

## 独立验收

### 第 1 次尝试：`gpu128-proxy` — 通过

| 人数 | 前版胜率 | 候选胜率 | 提升（百分点） | 95% 差值区间 | 多次尝试校正后的单侧下界 |
|---|---:|---:|---:|---|---:|
| 3 | 38.32% | 52.33% | +14.01 | [+12.39, +15.64] | +12.14 |
| 4 | 29.16% | 40.67% | +11.51 | [+10.16, +12.86] | +9.96 |

原始结果：[结果 JSON](../artifacts/progressive-upgrades/certificate-001/results.json)。每次共 28,672 局，全部回放审计。

### 第 2 次尝试：`proxy-v2-512-lowprior` — 通过

| 人数 | 前版胜率 | 候选胜率 | 提升（百分点） | 95% 差值区间 | 多次尝试校正后的单侧下界 |
|---|---:|---:|---:|---|---:|
| 3 | 53.07% | 56.11% | +3.05 | [+1.39, +4.70] | +0.83 |
| 4 | 40.40% | 44.68% | +4.27 | [+2.84, +5.71] | +2.36 |

原始结果：[结果 JSON](../artifacts/progressive-upgrades/certificate-002/results.json)。每次共 28,672 局，全部回放审计。

### 第 3 次尝试：`hybrid-wide-specialist` — 未通过

| 人数 | 前版胜率 | 候选胜率 | 提升（百分点） | 95% 差值区间 | 多次尝试校正后的单侧下界 |
|---|---:|---:|---:|---|---:|
| 3 | 56.76% | 58.81% | +2.05 | [+0.56, +3.52] | -0.12 |
| 4 | 45.55% | 48.10% | +2.56 | [+1.23, +3.89] | +0.61 |

原始结果：[结果 JSON](../artifacts/progressive-upgrades/certificate-003/results.json)。每次共 28,672 局，全部回放审计。

### 第 4 次尝试：`distill2048-specialist2048` — 通过

| 人数 | 前版胜率 | 候选胜率 | 提升（百分点） | 95% 差值区间 | 多次尝试校正后的单侧下界 |
|---|---:|---:|---:|---|---:|
| 3 | 55.09% | 58.36% | +3.27 | [+1.71, +4.84] | +0.89 |
| 4 | 45.25% | 47.79% | +2.54 | [+1.15, +3.94] | +0.40 |

原始结果：[结果 JSON](../artifacts/progressive-upgrades/certificate-004/results.json)。每次共 28,672 局，全部回放审计。

## 开发实验（不计升级）

| 实验 | 候选 | 三人相对参照提升 | 四人相对参照提升 |
|---|---|---:|---:|
| development-001 | rollout32-mixed | +6.51 点 | +4.23 点 |
| development-001 | rollout64-neural | +13.02 点 | +8.01 点 |
| development-001 | rollout64-risk | +11.20 点 | +8.01 点 |
| development-001 | rollout64-base | +9.90 点 | +0.39 点 |
| development-002 | gpu64-neural | +8.25 点 | +4.92 点 |
| development-002 | gpu128-neural | +12.54 点 | +10.35 点 |
| development-002 | gpu64-proxy | +6.42 点 | +11.26 点 |
| development-002 | gpu128-proxy | +16.32 点 | +9.47 点 |
| development-003 | proxy-v2-128 | -0.52 点 | -2.54 点 |
| development-003 | proxy-v2-256 | +6.51 点 | +0.81 点 |
| development-003 | belief-soft-256 | +4.64 点 | +1.24 点 |
| development-003 | belief-strong-256 | -0.26 点 | +3.73 点 |
| development-003 | continuation-256 | -1.56 点 | +2.00 点 |
| development-003 | belief-continuation-256 | -1.69 点 | +1.95 点 |
| development-003 | proxy-v2-512-lowprior | +4.69 点 | +2.96 点 |
| development-003 | proxy-v2-256-greedy | -1.56 点 | +1.53 点 |
| development-004 | wide-2048 | +9.11 点 | +1.50 点 |
| development-004 | purewin-1024 | +8.07 点 | +4.10 点 |
| development-004 | ppo-1024 | +0.52 点 | +0.98 点 |
| development-004 | specialist-1024 | +5.21 点 | +5.86 点 |
| development-004 | specialist-prior-1024 | +5.21 点 | +8.79 点 |
| development-004 | belief-split-1024 | +6.77 点 | +3.52 点 |
| development-005 | graph-1024-control | +3.65 点 | +1.56 点 |
| development-005 | distill-v2-1024 | +2.08 点 | +10.16 点 |
| development-005 | two-card-256 | +8.33 点 | +4.69 点 |
| development-005 | two-card-512 | +6.25 点 | +7.42 点 |
| development-005 | two-card-distill-256 | +4.17 点 | +3.78 点 |
| development-006 | hybrid-wide-specialist | +6.42 点 | +3.25 点 |
| development-006 | hybrid-pair-distill | +0.39 点 | +0.94 点 |
| development-006 | specialist-prior-1024 | +0.39 点 | +3.25 点 |
| development-006 | two-card-512 | +5.69 点 | -1.72 点 |
| development-007 | pair512-specialist2048 | +4.38 点 | +1.82 点 |
| development-007 | purewin2048-specialist2048 | +3.06 点 | +1.82 点 |
| development-007 | belief2048-specialist2048 | +3.17 点 | +1.82 点 |
| development-007 | distill2048-specialist2048 | +4.28 点 | +1.82 点 |
| development-008 | pair512-specialist2048 | +3.34 点 | +3.75 点 |
| development-008 | distill2048-specialist2048 | +4.85 点 | +3.75 点 |

不同开发实验的参照、牌局不同，不能用不同实验的原始胜率直接相减。开发候选的区间未经候选选择校正，最终结论只看独立验收。

## 已完成训练

| 训练 | 训练状态数或对局数 | 开发验证状态数 |
|---|---:|---:|
| opponent-proxies-v1 | 84582 | 22158 |
| opponent-proxies-v2 | 144306 | 36162 |
| opponent-proxies-v3-devshift | 189180 | 46044 |
| continuation-v1 | 5985 | 2079 |
| continuation-v2 | 24507 | 7749 |
| continuation-v3-fourp | 17028 | 3708 |
| ppo-proxy-v1 | 65536 | — |
| qstudent-v1 | 848 | 176 |
| ppo-specialist-3-v1 | 131072 | — |
| ppo-specialist-4-v1 | 131072 | — |

## 开发对局中的对手预测训练

第三版对手预测从第二版各对手权重继续训练，使用已完成的 development-004 至 007 中抽取的 4,096 局和旧数据。按原始牌局分组划分训练与验证，旧／新来源各占一半训练采样和验证选择权重。训练使用两条 CPU 线程；其权重尚未加入本轮已冻结的 development-008。

| 对手预测模型 | 选中轮次 | 旧验证 NLL（初始→选中） | 新验证 NLL（初始→选中） |
|---|---:|---:|---:|
| dirv-10000 | 10 | 1.1321 → 1.0983 | 1.0828 → 1.0300 |
| alpha-2000 | 3 | 1.5726 → 1.5699 | 1.5748 → 1.5682 |
| mcs | 4 | 1.5526 → 1.5495 | 1.5544 → 1.5487 |
| champion-search | 4 | 1.1153 → 1.0974 | 1.1294 → 1.1157 |

NLL 是对出牌概率的预测误差，越低越好。开发验证误差下降不等于比赛胜率提升，不能计为正式升级。

## 四人强搜索续局蒸馏

从四人 PPO 专项网络继续训练，模仿已完成的 development-004、006、007 中共 2,304 局、576 个原始牌局的强搜索行动。训练与验证按整副牌划分，固定 20 轮，并把初始权重纳入选择。

选中第 20 轮：验证 NLL 从 1.5802 降至 1.0788，出牌预测准确率从 56.80% 变为 58.58%。

该权重保存在 continuation-v3-fourp，尚未加入已冻结的 development-008。模仿指标须通过后续新牌局比赛验证，不能计为正式升级。

## 四人续局网络的 CPU 开发对照

三种网络分别在两套学习得到的预测对手下各打 4,096 局，共 24,576 局。自方座位固定，初始牌局、对手类型和动作随机流配对；这些对手并非正式验收使用的真实搜索程序。

| 预测对手池 | 续局网络 | 胜率 | 相对原四人 PPO | 普通配对 95% 区间 |
|---|---|---:|---:|---:|
| proxy-v2 | original-ppo4 | 38.35% | +0.00 点 | [+0.00, +0.00] 点 |
| proxy-v2 | shared-distill-v2 | 36.59% | -1.76 点 | [-3.52, -0.01] 点 |
| proxy-v2 | fourp-distill-v3 | 39.97% | +1.62 点 | [-0.03, +3.25] 点 |
| proxy-v3 | original-ppo4 | 38.50% | +0.00 点 | [+0.00, +0.00] 点 |
| proxy-v3 | shared-distill-v2 | 37.82% | -0.68 点 | [-2.46, +1.08] 点 |
| proxy-v3 | fourp-distill-v3 | 39.66% | +1.16 点 | [-0.52, +2.83] 点 |

新四人网络在两套预测对手下的点估计均为正，但普通区间都包含零。该结果只作为后续开发线索，不计为正式提升；已冻结的 development-008 保持原配置。

## 续局网络的模拟对手开发对照：continuation-comparison-001

以下对手是学习得到的近似模型，不能代替真实本地对手池验收。各网络在每个人数下评测 2,048 局。

| 网络 | 三人胜率 | 四人胜率 |
|---|---:|---:|
| base | 39.55% | 30.35% |
| imitation | 43.69% | 34.88% |
| ppo | 44.44% | 35.43% |
| qstudent | 41.62% | 31.64% |

## 续局网络的模拟对手开发对照：continuation-comparison-002

以下对手是学习得到的近似模型，不能代替真实本地对手池验收。各网络在每个人数下评测 4,096 局。

| 网络 | 三人胜率 | 四人胜率 |
|---|---:|---:|
| base | 39.86% | 32.20% |
| imitation-v1 | 45.03% | 35.62% |
| imitation-v2 | 47.17% | 38.02% |
| ppo-shared | 46.33% | 36.47% |
| ppo-specialist | 47.13% | 37.78% |

所有正式结论限定于三人、四人、104 张牌及冻结的八模型对手池。各策略推理预算不同，搜索增益不代表等算力增益。
