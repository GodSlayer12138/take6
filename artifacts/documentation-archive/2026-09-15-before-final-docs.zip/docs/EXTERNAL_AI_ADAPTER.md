# rl-6-nimmt 外部 AI 适配说明

目标仓库：[`johannbrehmer/rl-6-nimmt`](https://github.com/johannbrehmer/rl-6-nimmt)，MIT License。源码快照位于 `external/rl-6-nimmt`。

## 为什么同一个游戏不能直接加载

| 层 | 上游实现 | 本项目 | 适配方式 |
|---|---|---|---|
| 牌号 | `0..103` | `1..104` 或 `1..10n+4` | 边界处统一 `±1` |
| 最低牌选行 | 自动收牛头最少行 | 人类可选择，AI 默认收牛头最少行 | 外部 AI 评测时使用自动规则 |
| 状态 | 47 个连续数值 | 结构化对象、完整公开牌记忆 | `encodeRl6NimmtState()` |
| 动作 | 104 维牌号或 action-conditioned 标量 | 直接返回实际牌号 | 只在当前手牌上做合法动作掩码 |
| 牌池 | 默认固定 104 | 固定 104 / `10n+4` | MCS 可泛化；旧神经网络建议只用于 104 |
| 人数 | 归一化按 0—6，实验主要 2—4 人 | 2—10 人 | 原权重仅在训练分布内评测才公平 |
| 模型 | PyTorch Agent / state_dict | 浏览器 Web Worker | state_dict 转换为纯 JSON 全连接层 |

## 已接入内容

1. **公开 MCS · 适配**：完整移植上游 `MCSAgent` 的核心思想——对未知手牌采样，并用随机策略模拟整局。它不需要神经网络权重，已经加入竞技场。
2. **47 维状态编码**：手牌 10、人数 1、四行长度 4、四行尾牌 4、四行牛头 4、`4×6` 牌列，共 47 维。
3. **归一化**：逐段复刻上游 `SechsNimmtStateNormalization`。
4. **模型运行时**：支持 action-conditioned PolicyMCS/PUCT policy head，以及普通 104 动作 value head；始终对当前手牌做合法动作过滤。
5. **安全转换器**：`tools/export_rl6nimmt_policy.py` 只接受 `state_dict`，使用 `torch.load(..., weights_only=True)`，不会执行任意 pickle 对象。

## 上游缺少什么

公开仓库没有 `.pt`、`.pth` 或 `.tournament*.pickle` 模型文件。Notebook 中的最终模型保存在本地隐藏文件 `.tournament.pickle`，该文件被 `.gitignore` 排除。因此：

- MCS 可以立即公平适配；
- Alpha0.5/PUCT、D3QN、ACER 只有网络定义，没有已训练参数；
- README 中的 Elo 不能当作可下载权重，也不能直接在本项目复现。

## 获得权重后的转换

对可信来源的 `PolicyMCSAgent` / `PUCTAgent`，先在原环境中只保存 actor 权重：

```python
torch.save(agent.actor.state_dict(), "alpha05_actor_state_dict.pt")
```

再转换：

```powershell
# 重建项目环境时使用；转换本身使用 CPU 即可
conda create -n ntw-ai python=3.11 -y
conda run -n ntw-ai python -m pip install torch --index-url https://download.pytorch.org/whl/cpu
conda run -n ntw-ai python tools/export_rl6nimmt_policy.py `
  alpha05_actor_state_dict.pt public/models/alpha05.json
```

上述适配工作最初未取得可转换的上游权重。当前 `ntw-ai` 环境已安装 PyTorch/CUDA，并完成本地 Alpha／DirV 复现训练；这些权重并非上游作者的原始训练模型。当前对比结果、其他公开模型的覆盖缺口及闭源系统未测试的边界，见 [技术报告第 7.1 节](TECHNICAL_REPORT.md#71-与网上公开实现论文方法及闭源系统的对比)。

不要直接加载来源不明的 `.pickle` 或整个 `torch.save(agent)` 文件；这类旧格式可能在反序列化时执行代码。

## 公平比较原则

- 固定发牌种子并轮换座位；
- 所有 AI 只读取自己的手牌和公共状态；
- Alpha0.5 原权重只在固定 104 张、2—4 人中报告主结果；
- 最低牌统一采用“收牛头最少行”，与上游简化规则一致；
- 同时报告胜率、平均牛头、平均名次和置信区间，不只挑最好看的指标。
