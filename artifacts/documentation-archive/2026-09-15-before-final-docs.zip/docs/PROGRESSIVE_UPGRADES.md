# 三人、四人连续升级实验

本轮目标是完成 **三次连续的、独立验收通过的升级**。每次新版本须在三人和四人中同时超过上一接受版本。仅开发赛获胜或增加版本号不计数。进度以 `artifacts/progressive-upgrades/state.json` 为准。

## 固定验收规则

- 固定 104 张牌；不运行五人及以上比赛。每局 10 轮，第一名并列时平分胜局份额。
- 从已有 V5 行对称集成策略起步。对手从协议中的八个本地模型等概率抽取，不重复；对手身份不提供给策略。
- 每次验收在三人、四人中各生成 **2,048 个独立牌局**。新旧策略使用相同牌局、对手和全部座位轮换；合计 **28,672 局**。
- 策略配置、权重、代码摘要及完整样本数在运行前冻结。验收牌局不与历史开发牌局或其他本轮实验重复。中途不计算验收胜率来决定停止或改参数。
- 以独立牌局为重采样单位，保留同一牌局各座位、新旧策略之间的关联；做 200,000 次配对 bootstrap。
- 第 j 次验收使用 alpha = 0.05 / [j(j+1)]，三人、四人各分一半。两种人数下，调整后的单侧差值下界均须大于零，且观测提升均至少 **0.5 个百分点**。失败也消耗当次额度。
- Bootstrap 显著性是有限样本的近似推断；额度分配控制反复尝试带来的多重比较风险。结论只覆盖本对手池和规则，不证明已击败所有开源模型。
- 搜索版本可以增加计算量，报告同时披露每次决策耗时；不宣称相同算力下胜出。

机器可读协议为 `artifacts/progressive-upgrades/protocol.json`，失败与成功验收均保留原始逐步出牌记录，结果报告生成前重新回放全部对局。

## 正在探索的方法

1. **以最终胜率为目标的完整回合模拟**：从未知牌中采样互不重叠的对手手牌，枚举己方候选牌，模拟到本局结束；候选使用相同随机世界降低差值噪声。V5 输出用作弱先验。
2. **对手行为蒸馏**：用历史公开记录训练 DirV、Alpha、MCS、champion-search 的行动近似模型，训练和验证按整副牌划分。共 106,740 个行动状态，84,582 用于训练、22,158 用于验证。历史记录在本轮中明确作为开发资料，后续验收使用新牌局。
3. **根据历史行为更新推测**：根据已公开的出牌，为采样的剩余手牌、对手类型计算软似然，使用温度、均匀混合和有效样本量下限缓解模型误差。其是否有效仍需开发比赛和独立验收。
4. **学习更好的续局策略**：行为蒸馏学习搜索选中的牌；PPO 直接优化模拟整局的胜局收益；收益蒸馏学习每张候选牌的相对预期收益。另训练三人、四人专项网络。训练收益与模拟对手胜率不计入正式升级次数。
5. **两步出牌计划**：先做普通搜索筛选三张首牌，再为每张首牌枚举第二张牌，模拟完整剩余回合。两张己方牌在所有隐藏手牌样本中使用同一顺序，之后由续局网络选择；真实下一轮仍根据新公开信息重新规划。它不读取真实对手手牌。增加枚举可能引入估计偏差，是否有效以新的开发和正式比赛为准。

第二版搜索蒸馏使用已完成的 development-002、003：24,507 个训练状态、7,749 个按整副牌划分的验证状态。三人和四人专项 PPO 网络各训练 131,072 局，另有共享 PPO 的 65,536 局。正式验收轨迹均未加入这些训练。

## 执行加速实验

后续开发候选可显式启用 `cuda_graphs`，在单独的环境模块中捕获重复 GPU 运算，保持普通／历史已归档策略的运行模块不变。捕获图按线程隔离，复用输入输出缓冲区及相同冻结权重，校验期间已对照 1,280 个回合状态、280 次历史决策，并完成两步计划的 42 项检查。缓存、并发改动不计为策略升级。

certificate-002 与 development-004 使用运行前冻结的共享 GPU 服务；2026-09-10 的续跑阶段分别独占服务，均使用四条 CUDA 流、八个 CPU 对局进程。早期部分牌局曾并行运行或使用不同进程数。development-005 使用单进程运行以限制 Windows 提交内存。各结果的决策耗时包含当时资源竞争，不能直接当作独占机器的延迟基准。

GPU 环境已与 NumPy 环境对照校验 640 个回合状态、12,320 个候选特征向量。另通过 128 项历史状态重建、隐藏信息不变性、人数配置切换和追加模拟检查。当前进度见 [持续更新的结果报告](PROGRESSIVE_UPGRADES_RESULTS.md)。

## 第三次升级的入围复测

development-004 和 development-005 已完整结束并回放审计。development-006 在新牌局上复测四个候选：

| 候选 | 三人配置 | 四人配置 |
|---|---|---|
| `specialist-prior-1024` | 1,024 样本、三人专项网络及其先验 | 1,024 样本、四人专项网络及其先验 |
| `two-card-512` | 256 样本筛选首牌、512 样本评估两张牌计划 | 同三人配置 |
| `hybrid-wide-specialist` | 2,048 样本普通续局模拟 | 四人专项网络及其先验、1,024 样本 |
| `hybrid-pair-distill` | 256 样本两张牌计划 | 第二版蒸馏续局网络、1,024 样本 |

前两个候选保留原配置、归档代码及权重。两个组合方案分别组合各开发批次中三人、四人点估计最高的配置，随后在新数据上检查组合是否有效。人数切换仅使用公开的参赛人数。

参照为第二次验收通过的 `proxy-v2-512-lowprior`。每种人数预先冻结 256 个新牌局，五个策略使用相同牌局、对手及全部座位轮换，共 8,960 局。完整结果生成后，候选须在两种人数下都至少提高 0.5 个百分点，再按两项提升中的较小值排序；相同时比较平均提升，仍相同时按策略 ID 字典序选择。未达到条件则继续开发，不提前缩减样本或计作升级。

本轮使用两条 CUDA 流和八个 CPU 对局进程。运行前，对五个策略同时发起并发检查，共 700 次历史决策全部匹配，覆盖组合方案的人数切换和 CUDA 图执行。冻结配置及选择规则见 [development-006 manifest](../artifacts/progressive-upgrades/development-006/manifest.json)，检查记录见 [validation-result.json](../artifacts/progressive-upgrades/development-006/validation-result.json)。最终入围者仍须使用全新的正式验收牌局通过原有门槛。

完整复测共 8,960 局，已通过回放审计。`hybrid-wide-specialist` 的三人、四人开发提升分别为 +6.42、+3.25 个百分点，是唯一满足本批双人数开发筛选条件的候选。其他候选中，两个方案的三人提升不足 0.5 个百分点，`two-card-512` 的四人提升为负。筛选记录见 [selection-003.json](../artifacts/progressive-upgrades/selection-003.json)。这些开发结果不计为第三次显著提升。

第三次正式验收已冻结为 [certificate-003 manifest](../artifacts/progressive-upgrades/certificate-003/manifest.json)，沿用前述 28,672 局及多次尝试校正规则。候选和参照均不启用 CUDA 图；本次使用四条 CUDA 流、八个 CPU 对局进程，启动前的 280 次归档决策对照全部一致。正式通过状态仍以 `state.json` 和独立审计结果为准。

### 第三次验收结果与后续开发

`certificate-003` 于 2026-09-11 完成全部 28,672 局。三人提升 2.0454 个百分点、四人提升 2.5553 个百分点；多次尝试校正后的单侧下界分别为 **−0.1194** 和 **+0.6083** 个百分点。三人未通过冻结门槛，因此该次尝试**不计为第三次升级**。普通 95% 区间为正不等于通过本轮预先规定的更严格门槛。独立审计已重新回放并重算前三次验收的全部 86,016 局，确认接受次数仍为 2，基线仍为 `proxy-v2-512-lowprior`。

下一轮 [development-007](../artifacts/progressive-upgrades/development-007/manifest.json) 在新开发牌局中比较四种配置：

| 候选 | 三人策略 |
|---|---|
| `pair512-specialist2048` | 先以 256 个世界筛选首张牌，再以 512 个世界比较两张牌的计划 |
| `purewin2048-specialist2048` | 2,048 个世界，目标仅为获胜份额，去掉先验与牛头数辅助权重 |
| `belief2048-specialist2048` | 2,048 个世界，用公开历史对对手及未知手牌的估计重新加权 |
| `distill2048-specialist2048` | 2,048 个世界，使用 `continuation-v2` 蒸馏网络模拟后续出牌 |

四个候选的四人策略统一使用 2,048 个世界和四人 PPO 专项网络，且均不启用 CUDA 图。参照是第二次正式通过的原配置。每种人数先完成 256 组配对开发牌局；两项观察提升都至少 0.5 个百分点的候选中，按较小提升、平均提升及策略 ID 排序，最多取两个进入各 512 组全新开发牌局的复测。复测只有在两项观察提升均至少 0.5 个百分点且两项普通 95% 配对区间下界均大于零时，才有资格进入新正式验收；完整排序规则已写入 manifest。没有合格候选就继续开发。

新配置先在已完成的 `development-006` 公开观测上生成直接推理结果，再对照共享服务的并发推理结果。该检查只检验执行一致性，不检验强度，也不使用正式验收牌局选权重。失败验收、暂停与恢复记录全部保留，下一次正式尝试继续消耗预先规定的第 4 次 alpha 配额。

阶段推进脚本为 [advance_progressive_development7.py](../training/advance_progressive_development7.py)。`--stage screen` 仅在 development-007 完整结果生成后按冻结规则选出最多两个候选，并准备 development-008；`--stage replication` 仅在完整复测合格后准备第 4 次正式验收。脚本核对来源摘要、原策略身份和完整样本数，不启动比赛，不修改已有结果；样本未完成时不写入选择记录或下一阶段 manifest。

development-007 已完成全部 8,960 局。按冻结排序入选的是 `pair512-specialist2048` 和 `distill2048-specialist2048`：三人开发提升分别为 4.3837、4.2752 个百分点，四人均为 1.8229 个百分点。这些是开发观察值，普通区间仍包含较大不确定性。选择记录及独立核对分别见 [selection-development-007.json](../artifacts/progressive-upgrades/selection-development-007.json) 和 [独立选择审计](../artifacts/progressive-upgrades/selection-development-007-independent-audit.json)。

两者已原样复制至 [development-008](../artifacts/progressive-upgrades/development-008/manifest.json)，与同一接受基线在每种人数各 512 组全新牌局中复测，共 10,752 局。启动前的 420 次归档决策对照全部一致。完整复测达标者再进入第 4 次正式验收；开发胜率继续不计入已接受升级次数。

### 补充对手预测训练

`opponent-proxies-v3-devshift` 从第二版四个对手预测网络分别继续训练。它从已完成的 development-004、005、006、007 中，按冻结随机种子抽取三人、四人各 2,048 局，覆盖 1,039 个原始牌局，共重建 54,756 个行动状态。只提取真实搜索对手当时自己的手牌与公开局面；不使用正式验收或尚未完成的开发对局。

原始牌局的全部座位轮换及策略变体保持同一训练／验证归属。每个小批次的旧、新数据各占一半；各对手以两种来源等权的验证 NLL 选择权重，初始第二版权重也在候选中。每个对手固定训练 12 轮，每轮保存指标，并更新模型、优化器及采样状态的恢复检查点。运行使用两条 CPU 线程和按批读取的文件映射数据，当前 development-008 的模型、预算和选拔规则保持冻结。

入口为 [train_progressive_opponents_v3.py](../training/train_progressive_opponents_v3.py)，协议为 [第三版对手预测训练协议](../artifacts/progressive-upgrades/opponent-proxies-v3-devshift/protocol.json)。启动前已验证 8 局回放、108 个新行动、四个模型的有限梯度，以及优化器恢复后下一步参数完全一致。预测误差变化仅作为开发训练指标；新权重只有经过后续新牌局测试，才能判断是否提高比赛胜率。

该训练已于 2026-09-12 完成，共使用 189,180 个训练状态和 46,044 个验证状态。四个对手模型在旧、新验证资料上的 NLL 均下降；选中轮次分别为 DirV 第 10 轮、Alpha 第 3 轮、MCS 第 4 轮、champion-search 第 4 轮。另一个脚本以不同批次大小和双精度对数概率计算复核初始及选中模型，同时检查 48 轮记录、训练来源摘要、整副牌分组和 PT／JSON 权重一致性，已全部通过。入口及结果见 [独立训练审计脚本](../training/audit_progressive_opponents_v3.py) 和 [independent-audit.json](../artifacts/progressive-upgrades/opponent-proxies-v3-devshift/independent-audit.json)。

CPU 训练与 development-008 的部分三人对局重叠，决策耗时包含当时的资源竞争；起止及资源记录保存在 [resource-events.json](../artifacts/progressive-upgrades/development-008/resource-events.json)。新模型仅供后续新的开发实验使用，当前复测保持原有冻结权重。

### 四人续局网络的强搜索蒸馏

`continuation-v3-fourp` 从原四人 PPO 专项权重继续训练，模仿 development-004 的 `specialist-prior-1024`、development-006 的 `hybrid-wide-specialist` 和 development-007 的 `pair512-specialist2048` 在四人局中的出牌。三者的四人教师分别使用 1,024、1,024、2,048 个模拟世界；每个开发实验只选一个四人教师，避免把相同配置的重复记录重复加入。

共使用 2,304 局，覆盖 576 个原始牌局，得到 17,028 个训练行动和 3,708 个验证行动。整副牌的全部座位轮换归属一致。训练从四人专项 PPO 网络初始化，使用行位置置换增广、固定 20 轮、两条 CPU 线程；按验证交叉熵选择，初始权重也在候选中。

20 轮已于 2026-09-12 完成。选中第 20 轮，验证 NLL 从 1.5802 降至 1.0788，出牌预测准确率从 56.80% 变为 58.58%。独立脚本以不同批次大小和双精度对数概率复算初始及选中模型，并核对来源摘要、全部 20 轮记录、仅使用四人数据、整副牌划分及 PT／JSON 权重一致性，全部通过。该模型尚未经过新比赛检验，不计为显著胜率提升。

训练入口为 [train_progressive_continuation_v3.py](../training/train_progressive_continuation_v3.py)，核对入口为 [audit_progressive_continuation_v3.py](../training/audit_progressive_continuation_v3.py)，证据见 [训练协议](../artifacts/progressive-upgrades/continuation-v3-fourp/protocol.json) 和 [独立核对结果](../artifacts/progressive-upgrades/continuation-v3-fourp/independent-audit.json)。它同样仅供后续新开发实验使用，未改变 development-008 的冻结策略。

### 四人续局网络的开发比赛对照

`four-player-proxy-diagnostic-001` 已冻结并完成 24,576 局 CPU 开发比赛。比较原四人 PPO、共享的第二版蒸馏网络、新四人蒸馏网络，分别使用第二版和第三版预测对手池。每个网络在每套预测对手池下各打 4,096 局，固定自方座位；初始牌局、无放回抽取的对手类型和动作随机流相同。批次使用新的 64 位高位种子命名空间，与正式验收的 32 位牌局种子分开。

三种网络对原四人 PPO 的开发差值见结果报告。新四人蒸馏网络在第二版预测对手下为 **+1.6215** 个百分点，普通 95% 配对区间 **[−0.0264, +3.2532]**；在第三版预测对手下为 **+1.1576** 个百分点，区间 **[−0.5188, +2.8341]**。两项区间均包含零，因此这些结果仅支持保留候选，不证明显著提升。它们也不能替代真实八模型对手池的独立验收。

启动前已检查六种组合及重复运行的一致性，回放 56 局；完整对照生成后，另一个脚本重新回放全部 24,576 局，独立重算配对差值和 20,000 次 bootstrap，核对来源及权重摘要，全部通过。入口为 [evaluate_four_player_proxy_diagnostic.py](../training/evaluate_four_player_proxy_diagnostic.py)，核对入口为 [audit_four_player_proxy_diagnostic.py](../training/audit_four_player_proxy_diagnostic.py)，证据见 [协议](../artifacts/progressive-upgrades/four-player-proxy-diagnostic-001/protocol.json)、[结果](../artifacts/progressive-upgrades/four-player-proxy-diagnostic-001/results.json) 和 [独立核对](../artifacts/progressive-upgrades/four-player-proxy-diagnostic-001/independent-audit.json)。正式升级次数仍只由原验收协议决定。

## 可复现入口

### 第四次正式验收的恢复记录

2026-09-13 接续时，`certificate-004` 仅有已冻结的清单，尚未启动比赛。先独立重放并复算了 development-008 的全部 10,752 局，确认 `distill2048-specialist2048` 按原排序入围，三人、四人开发提升分别为 +4.8503、+3.7516 个百分点。候选与接受基线均保持复测时的配置、归档代码及权重。随后使用两条 CUDA 流、八个并发客户端，对照已完成 development-008 的 280 次出牌，全部匹配。

独立选择审计见 [selection-development-008-independent-audit.json](../artifacts/progressive-upgrades/selection-development-008-independent-audit.json)，启动前一致性证据见 [certificate-004/validation-result.json](../artifacts/progressive-upgrades/certificate-004/validation-result.json)。正式验收仍为三人、四人各 2,048 组、共 28,672 局，每种人数的 alpha 为 0.00125；开发结果不计为第三次升级。

本轮由 [supervise_progressive_certificate.py](../training/supervise_progressive_certificate.py) 在本机后台管理八个对局进程，持续保存完整组数。监督程序独立于冻结的比赛和模型代码；比赛结束后执行原独立审计脚本，达到三次接受升级时追加 `--require-complete`，然后更新结果报告并关闭空闲 GPU 服务。临时防待机请求只在接通电源且比赛进程存活时生效。运行状态见 [supervisor-status.json](../artifacts/progressive-upgrades/certificate-004/supervisor-status.json)；异常、验收未通过及其 alpha 消耗均保留，不自动更换冻结策略。

使用本机 `D:/Programs/miniconda3/envs/ntw-ai/python.exe`：

```powershell
& 'D:/Programs/miniconda3/envs/ntw-ai/python.exe' training/progressive_torch_env.py
& 'D:/Programs/miniconda3/envs/ntw-ai/python.exe' training/verify_progressive.py
& 'D:/Programs/miniconda3/envs/ntw-ai/python.exe' training/progressive_campaign.py --manifest artifacts/progressive-upgrades/development-002/manifest.json --workers 6
```

中断后可使用原 manifest 续跑，已完成牌局不重新抽样。验收候选应从已结束的开发实验中选择；使用 `--certify-development <开发实验名> --candidate <候选名>` 冻结并验收。不能因验收失败而修改当次配置重新计为同一次尝试。
