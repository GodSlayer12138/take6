# ETH 一步价值预测方法复现

本轮已完成 12,000 局自博弈训练和 1,800 局正式评测。[实验结果与限制](ETH_REPRODUCTION_RESULTS.md)。

目标是独立复现 Fabio Bertschi、Jean Mégret 的
[2022 年报告](https://pub.tik.ee.ethz.ch/students/2021-HS/GA-2021-02.pdf)第 5.6 节。
没有使用作者训练权重，也不把本实现称为原版 ETH 模型。

## 方法与实验条件

- Alpha0.5 基线：PUCT 选择根动作，神经策略引导所有模拟玩家，一直模拟到十回合结束。
- DirV：同样选择根动作，但只模拟一步，使用 `即时奖励 + 0.99 × V(下一状态)` 评价余局。
- 只在真实训练牌局结束后更新模型；策略拟合搜索选出的动作，价值拟合折扣剩余罚分。
- 固定 104 张、四人，每人十张；最低牌自动收罚分最少行，同分按最先行号。
- 两组各由四个独立同类网络自博弈。Alpha 训练 2,000 局，DirV 训练 10,000 局，均设 50 次模拟上限。
- 冻结最后检查点的第 0 个网络。评测为 Alpha、DirV 和两个随机玩家，模拟上限分别 50、200。

上述次数沿用论文；本机实际耗时单独测量。论文强调同耗时优势，次数相同不能自动证明时间预算相同。
测试集在 `artifacts/eth-reproduction/experiment-plan.json` 预先确定：400 局主测试和另外 1,000 局复核。
另设 400 局相同训练耗时对照：Alpha 完成 2,000 局时，保存当时已经完成的 DirV 检查点，
要求累计训练耗时相差不超过 5%。这个检查点按时间选取，不查看评测胜率。

## 缺失信息与实现假设

| 项目 | 本次选择 | 来源或限制 |
|---|---|---|
| Alpha 网络 | 动作与状态共 48 维，100→100→1，ReLU | 上游默认结构 |
| DirV 网络 | 47→100→100，共享干层；104 维策略头和 1 维价值头 | 报告未给完整尺寸及策略头编码，本次明确选择 |
| 优化器 | Adam，学习率 0.001 | 沿用上游默认值；ETH 配置未公开 |
| 策略损失 | 实际搜索动作负对数概率之和 | 沿用上游训练目标 |
| DirV 总损失 | 策略损失 + 价值 MSE 均值 | 报告描述相加；具体缩放不明，采用单位权重 |
| 训练目标 | 从当前动作起的剩余负罚分，含末步奖励 | 折扣 0.99；显式处理奖励时序 |
| PUCT | c=2；上游 Q 归一化及最终平均回报选择 | 相同回报导致零分母时设 exploitation 为零 |
| 模拟数量 | min(上限, 10×剩余手牌数的阶乘)；单张直接出 | 上游默认预算逻辑 |
| 对手信息 | 只收到自身 47 维观察，模拟手牌从可用牌中采样 | 保留上游基于已观察牌面的记忆方式 |
| 并列夺冠 | 主指标平分胜利份额；另报独胜和上游首座位破平结果 | 论文未详述并列口径 |
| 发牌与随机数 | 独立确定性 RNG，四次轮换同一副牌 | 作者原始种子未知；统计按发牌组聚类 |

这些假设使本工作属于“按公开方法重新实现并训练”。即使胜率相似，也不能宣称逐项精确复现作者模型。

## 运行

只使用项目已有 `ntw-ai` 环境及 NumPy、PyTorch，无需安装旧 Gym 等无关依赖。

```powershell
& D:/Programs/miniconda3/envs/ntw-ai/python.exe training/test_eth_reproduction.py

& D:/Programs/miniconda3/envs/ntw-ai/python.exe training/reproduce_eth_dirv.py train --kind alpha --games 2000 --simulations 50 --seed 60811001 --save-every 25 --workers 4 --output artifacts/eth-reproduction/paper-alpha
& D:/Programs/miniconda3/envs/ntw-ai/python.exe training/reproduce_eth_dirv.py train --kind dirv --games 10000 --simulations 50 --seed 60812001 --save-every 100 --workers 4 --output artifacts/eth-reproduction/paper-dirv

& D:/Programs/miniconda3/envs/ntw-ai/python.exe training/reproduce_eth_dirv.py evaluate --alpha artifacts/eth-reproduction/paper-alpha/checkpoint.pt --dirv artifacts/eth-reproduction/paper-dirv/checkpoint.pt --deals 100 --seed 60813001 --output artifacts/eth-reproduction/paper-evaluation
& D:/Programs/miniconda3/envs/ntw-ai/python.exe training/reproduce_eth_dirv.py evaluate --alpha artifacts/eth-reproduction/paper-alpha/checkpoint.pt --dirv artifacts/eth-reproduction/paper-dirv/checkpoint.pt --deals 250 --seed 60814001 --output artifacts/eth-reproduction/replication-evaluation
```

训练中断后，使用原训练命令追加 `--resume`。总目标局数、种子、结构和优化参数要保持一致；源文件哈希不同会拒绝续训。
每个训练目录保存原子替换的 `checkpoint.pt`、逐局 `training.jsonl`、带源文件哈希的 `protocol.json`。
结束后写出 `summary.json`。评测要求新目录，保存逐局分数、轮换座位和两种模型的权重哈希。

独立发牌组也可并行评测：将上面评测命令中的 `reproduce_eth_dirv.py evaluate` 换为
`evaluate_eth_parallel.py`，追加 `--workers 4`。已对照试跑的 20 局记录，和串行输出完全一致。
并行时测得的是并发环境下的每步墙钟耗时；报告需要同时注明进程数。

四名玩家可以在独立进程同时计算同一回合的动作；测试确认它与串行执行的分数和更新后权重一致。
CPU 推理用同一组 PyTorch 参数的 NumPy 视图，训练仍用 autograd；测试在训练前后核对两条推理路径。
小网络的搜索主要是大量细小调用，因此默认 CPU。RTX 4060 可通过 `--device cuda` 使用，但不能预设它更快。

## 验证范围

- 500 个回合与原始上游 Python 环境逐步核对分数、牌列、47 维观察和结束条件。
- 核对上游特征归一化、同分选行、末步奖励、隐藏手牌隔离。
- 核对搜索与评测不改权重、训练产生有限梯度且更新策略/价值参数。
- 核对串行与四进程训练一致，并保留原始上游源码及 MIT 许可证。

主结论使用逐发牌组配对 bootstrap 的胜率差 95% 区间。同步报告平均牛头与每步耗时。
在训练和评测完成以前，不能把试跑胜率或训练损失作为“已复现论文领先”的证据。

本轮验证记录见 `artifacts/eth-reproduction/validation.json`。短程试跑仅用于检查流程，
正式的 400 局和 1,000 局评测使用不同的预先固定种子。

`training/finish_eth_reproduction.py` 负责监控本轮两组训练的完成文件、保存时间对照检查点，
并执行三组预声明评测，最终生成 `docs/ETH_REPRODUCTION_RESULTS.md` 和
`artifacts/eth-reproduction/complete.json`。它不按胜率调参或挑模型。

完成后运行以下命令，可从原始日志重新核对训练局数、胜率、平均牛头、座位轮换与文件哈希：

```powershell
& D:/Programs/miniconda3/envs/ntw-ai/python.exe training/audit_eth_reproduction.py
```
