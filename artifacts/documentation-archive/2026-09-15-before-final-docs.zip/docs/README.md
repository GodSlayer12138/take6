# 文档索引

当前入口是 [详细技术报告](TECHNICAL_REPORT.md)，覆盖仓库分层、信息边界、模型与搜索、训练来源、正式验收、网页集成、验证和本机部署。

| 用途 | 文档 |
|---|---|
| 启动游戏 | [根目录说明](../README.md) |
| 选择、保留或归档模型 | [模型索引](../models/README.md) |
| 当前三四人冠军成绩 | [正式结果](PROGRESSIVE_UPGRADES_RESULTS.md) |
| 外部开源、论文复现及闭源系统的覆盖与结果 | [技术报告第 7.1 节](TECHNICAL_REPORT.md#71-与网上公开实现论文方法及闭源系统的对比) |
| take6 作者二人／四人预训练权重实测 | [take6 评测报告](TAKE6_EVALUATION.md) |
| 正式升级规则与复现 | [连续升级协议](PROGRESSIVE_UPGRADES.md) |
| 二人 V6 及其他候选 | [小人数多路线结果](SMALL_PLAYER_EXPLORATION.md) |
| 研究适用范围 | [人数与规则约定](AI_EVALUATION_SCOPE.md) |
| 历史模型比较 | [本地随机联赛](LOCAL_MODEL_TOURNAMENT.md) |
| 外部参考 AI | [适配说明](EXTERNAL_AI_ADAPTER.md) · [复现方法](ETH_REPRODUCTION.md) · [复现结果](ETH_REPRODUCTION_RESULTS.md) |
| 早期版本与旧网页架构 | [项目历史](PROJECT_HISTORY.md) |

历史文档保留当时的结论和实现描述；当前默认网页模型与服务方式以技术报告为准。不同实验的胜率不可混成统一榜单。
