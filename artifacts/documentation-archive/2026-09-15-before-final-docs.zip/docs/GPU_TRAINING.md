# GPU 自博弈训练与验证

## 环境

- Conda：`ntw-ai`
- Python：3.11
- PyTorch：2.11.0 + CUDA 12.8
- GPU：NVIDIA GeForce RTX 4060 Laptop GPU（8GB）

安装命令：

```powershell
conda create -n ntw-ai python=3.11 -y
conda run -n ntw-ai python -m pip install torch==2.11.0 --index-url https://download.pytorch.org/whl/cu128
conda run -n ntw-ai python -m pip install numpy
```

所有 Python 训练、转换和检查都必须使用 `ntw-ai`，不使用 `base`。本轮实际命令固定调用
`D:\Programs\miniconda3\envs\ntw-ai\python.exe`，训练脚本也会检查 `sys.executable`，若环境目录不是
`ntw-ai` 会直接拒绝训练。

## 模型

发布模型是动作条件价值网络：

- 270 维公开信息特征；
- MLP：`270 → 256 → 128 → 64 → 1`，ReLU；
- 110,593 个参数；
- 输入包含自己的手牌、公开牌、四行牌列、比分摘要、人数、牌池与候选牌战术特征；
- 不包含对手真实手牌或未发出的牌；
- 通用浏览器模型位于 `src/game/models/ntw-champion.json`；五人固定 104 使用同结构的专项模型 `src/game/models/ntw-classic5.json`。

## 两轮训练

第一轮由高预算“冠军 v2”信息集搜索标注：

```powershell
node scripts/generate-training-data.mjs --games 800 --samples 32 `
  --players 3,4,5,6 --modes adaptive,classic --seed 41000000 `
  --output artifacts/training/expert-v1-train.jsonl
```

第二轮使用 v1 模型实际出牌，再由 44 次信息集采样教师重新标注（DAgger）：

```powershell
node scripts/generate-training-data.mjs --games 480 --samples 44 --players 5 `
  --modes adaptive,classic --seed 71000000 `
  --behavior-model src/game/models/ntw-champion.json `
  --output artifacts/training/dagger-v2-train.jsonl
```

合并训练：

```powershell
conda run -n ntw-ai python training/train_policy.py `
  --train artifacts/training/expert-v1-train.jsonl artifacts/training/dagger-v2-train.jsonl `
  --validation artifacts/training/expert-v1-validation.jsonl `
  --output src/game/models/ntw-champion.json `
  --checkpoint artifacts/models/ntw-champion-v2.pt `
  --epochs 80 --batch-size 512 --patience 12 --learning-rate 0.00035
```

训练总计 60,000 个状态、330,000 个候选动作。独立高预算验证集包含 7,200 个状态；v2 的教师首选一致率为 43.46%，前二覆盖率 67.78%，平均教师效用 regret 为 1.009。v1 分别为 41.05%、64.83%、1.055。

五人固定 104 专项模型从上述数据筛出 17,000 个训练状态，并在 1,000 个专项验证状态上达到 50.89% 首选一致率、76.44% 前二覆盖率和 0.607 regret。发布门控在该模式使用 15% 专项先验，并仅在前两候选预测差距至少 0.50 时介入搜索。

## 发布策略

纯神经网络负责快速价值先验；最终“牧场冠军 GPU”仍通过信息集搜索校验：

- 多候选共享同一批隐藏牌样本，降低动作差值方差；
- 精准牌池通常保留神经排名前半候选，并按候选数等比例增加采样，使总 rollout 预算与冠军 v2 近似；
- 固定 104 张开局使用密度规则，公开信息增加后使用全候选搜索和神经先验；
- 二人、三人局使用全随机 rollout 的低方差 MCS 变体，分别按牌池使用 5% 或 10% 神经先验；
- 六人固定 104 使用验证得到的 15% 神经先验。

## 留出种子结果

五人主基准（18 搜索样本；精准牌池 300 局，固定 104 为最终专项模型 1,000 局）：

| 模式 | 策略 | 胜率 | 平均牛头 | 平均名次 | 对冠军 v2 | 对公开 MCS |
|---|---|---:|---:|---:|---:|---:|
| `10n+4` | 牧场冠军 GPU | **29.7%** | **7.91** | **2.37** | 151:133（16 平） | 167:124（9 平） |
| `10n+4` | 冠军 v2 | 28.7% | 8.88 | 2.49 | — | — |
| `10n+4` | 公开 MCS | 26.2% | 10.11 | 2.68 | — | — |
| 固定 104 | 牧场冠军 GPU | **25.3%** | **10.31** | **2.64** | 496:474（30 平） | 512:455（33 平） |
| 固定 104 | 冠军 v2 | 24.7% | 10.84 | 2.69 | — | — |
| 固定 104 | 公开 MCS | 21.1% | 11.82 | 2.85 | — | — |

额外边界验证：

- 二人 `10n+4`：GPU 对冠军 v2 为 53.1%:46.9%，对公开 MCS 为 54.9%:45.1%（各 600 局）。
- 二人固定 104：GPU 对冠军 v2 为 57.8%:42.2%，对公开 MCS 为 50.3%:49.7%（各 600 局；平均牛头 5.91 对 6.33）。
- 三人 `10n+4`：GPU 39.7%、冠军 v2 26.6%、公开 MCS 33.6%（600 局）。
- 三人固定 104：GPU 37.3%、冠军 v2 27.9%、公开 MCS 34.8%（800 局）。
- 四人两种牌池、六人 `10n+4` 的混合场中 GPU 均排名第一；六人固定 104 的独立 300 局中 GPU 为 24.8% / 10.65 牛头，冠军 v2 为 20.8% / 11.08。

这些数字只证明本仓库的固定协议与已接入基线，不代表对互联网上所有未知实现的普遍领先。7—10 人目前能正常推理，但尚未完成同规模统计验证。

## 终局强化与自博弈实验（未替换发布冠军）

本轮新增三条可复现管线：

- `training/self_play_finetune.py`：完整十回合 REINFORCE、冻结策略 KL、五座位参数共享自博弈；
- `scripts/generate-arena-rl-data.mjs` + `training/arena_policy_finetune.py`：直接对真实竞技场对手采集轨迹，再做优势加权更新；
- `scripts/generate-counterfactual-data.mjs`：逐一替换合法候选牌并 rollout 到终局，生成动作级反事实标签。

RTX 4060 对称自博弈最终运行 300×128＝38,400 个完整对局、192,000 条玩家轨迹；训练日志确认
Python 3.11、PyTorch 2.11.0+cu128、RTX 4060 Laptop GPU，峰值显存约 75 MiB。每 50 轮保存检查点，
独立开发种子上 150 轮优于 200/250/300 轮，因此候选模型保留早停检查点而非最后一步。

为了检验“绝对提高 10 个百分点”，优化前先冻结两组从未调参的五人 1,000 局种子，搜索预算均为 18：

| 模式 | 发布冠军基线 | 10 点验收线 | 最终实验候选 | 结论 |
|---|---:|---:|---:|---|
| `10n+4` | 32.6% | 42.6% | 31.0% | 未通过，默认路由回退发布冠军 |
| 固定 104 | 26.8% | 36.8% | 25.8% | 未通过，默认路由回退发布冠军 |

开发种子上曾出现 35%—38% 的结果，但冻结集没有复现；因此没有把调参集峰值写成发布提升，也没有用增加
评测 rollout、选择有利种子或读取隐藏手牌来凑指标。强化与反事实模型保留为竞技场研究候选，默认模型
继续使用上一节已经通过留出验证的发布检查点。

回退后又单独校准了竞技场的公开对手类型：仅当 `10n+4` 模式明确提供参赛策略 ID 时，将搜索冠军近似为
谨慎 rollout、公开 MCS 近似为贪心 rollout；真实牌桌没有对手 ID 时仍使用通用混合分布。该改动在另一组
此前未使用、固定 18 次搜索预算的 1,000 局审计集上得到：

| 策略 | 胜率 | 平均牛头 | 平均名次 |
|---|---:|---:|---:|
| 回退后的通用发布路由 | 31.4% | 8.196 | 2.359 |
| 加入公开对手类型建模 | 34.3% | 7.733 | 2.301 |

因此自适应竞技场发布了这一算法改进，绝对提升为 2.9 点；它仍未达到 10 点目标。固定 104 的独立 300 局
验证只有 29.9%→30.1%，没有足够收益，故保持原路由。
