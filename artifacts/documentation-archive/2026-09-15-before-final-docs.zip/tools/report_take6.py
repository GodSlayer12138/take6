"""Render completed, audited take6 results into the repository reports."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'artifacts/take6-evaluation'
TITLES = {
    'four104_project': '四人 / 104 张，本项目规则',
    'four104_take6_rules': '四人 / 104 张，take6 选行规则',
    'two24_native': '二人 / 24 张，take6 原生规则',
    'two104_transfer': '二人 / 104 张，take6 迁移',
}
NAMES = {
    'distill2048-specialist2048': '当前冠军（2,048 世界）',
    'take6-4': 'take6 四人原始权重',
    'take6-2': 'take6 二人原始权重',
    'dirv-10000': 'DirV 本地复现',
    'mcs': 'MCS 适配版',
    'web-adaptive2': '网页兼容策略 neural_hybrid',
    'v6': 'V6 二人策略',
}


def interval(values, scale=1, signed=False):
    fmt = '+.2f' if signed else '.2f'
    return '['+', '.join(format(v*scale,fmt) for v in values)+']'


def comparison_table(results):
    lines = ['| 场景 | 本地模型 | 本地夺冠份额 | take6 夺冠份额 | 本地减 take6（百分点） | 差值 95% 区间 |',
        '|---|---|---:|---:|---:|---|']
    for mode, title in TITLES.items():
        s = results[mode]
        ranking = {r['id']:r for r in s['ranking']}
        a,b = ranking[s['ours']], ranking[s['take6']]
        lines.append(f"| {title} | {NAMES[s['ours']]} | {a['first_share']*100:.2f}% | {b['first_share']*100:.2f}% | {s['delta_first_share_pp']:+.2f} | {interval(s['delta_ci95_pp'],signed=True)} |")
    return lines


def main():
    result = json.loads((OUT/'results.json').read_text(encoding='utf-8'))
    audit = json.loads((OUT/'decision-audit.json').read_text(encoding='utf-8'))
    assert result['audited_games'] == audit['games'] == 1280 and audit['decisions'] == 12800
    assert audit['status'] == 'passed' and audit['complete']
    assert result['trace_sha256'] == audit['trace_snapshot_sha256']
    assert result['protocol_sha256'] == audit['protocol_sha256']
    summaries = result['summaries']
    primary = summaries['four104_project']
    lo,hi = primary['delta_ci95_pp']
    if lo > 0:
        conclusion = '主要比较的差值 95% 区间完全高于零，支持当前冠军在本次冻结四人对手池与规则下领先 take6。'
    elif hi < 0:
        conclusion = '主要比较的差值 95% 区间完全低于零，支持 take6 在本次冻结四人对手池与规则下领先当前冠军。'
    else:
        conclusion = '主要比较的差值 95% 区间跨越零，本轮不能确认当前冠军与 take6 的全桌夺冠份额存在差异。'
    lines = ['## 5. 比赛结果', '', '**固定计划的 1,280 局已完成，全部计分与动作回放通过。**', '']
    lines += comparison_table(summaries)
    lines += ['', conclusion, '',
        '第一行是预声明的主要比较；其余为补充场景，使用未校正的 95% 区间。四人结果是在当前冠军、take6、DirV、MCS 四个固定对手组成的同桌环境下测得，不能与原八策略混合池的 47.79% 直接相减，也不能合并成互联网模型的通用排名。', '',
        '二人 24 张的本地对手是网页兼容策略，二人 104 张的本地对手才是 V6。后者对 take6 是跨牌池迁移，不能据此评价其二人专家规则能力。网页模型路由及原三次正式升级记录保持原有身份；本次是外部对手评测，不是新候选对上一接受版本的正式升级验收。']
    for mode,title in TITLES.items():
        s = summaries[mode]
        lines += ['', f'### {title}', '',
            f"{s['games']} 局，{s['independent_deals']} 组完整座位轮换；每个模型在每个座位出场 {s['independent_deals']} 次。", '',
            '| 模型 | 夺冠份额 | 95% 区间 | 平均牛头 | 记录的每步计算毫秒 |',
            '|---|---:|---|---:|---:|']
        for r in s['ranking']:
            lines.append(f"| {NAMES[r['id']]} | {r['first_share']*100:.2f}% | {interval(r['ci95'],100)}% | {r['mean_bullheads']:.3f} | {r['mean_decision_ms']:.3f} |")
        lines += ['', f"本地模型相对 take6 的同桌比分胜出份额为 {s['ours_same_table_score_share']*100:.2f}%，95% 区间 {interval(s['same_table_score_ci95'],100)}%。" + (' 这是四人同桌最终比分比较，不是二人单挑胜率。' if mode.startswith('four') else '')]
    lines += ['', '### 完成核验', '',
        f"- 完成时间：`{result['completed_at']}`；1,280 局、448 个完整轮换块全部完成，没有遗漏座位或重复块。",
        '- 所有动作合法，牛头计分和并列第一份额经独立规则实现逐局重放。',
        '- 另外用上游编码器、独立 NumPy 前馈和重建的随机数审计全部 12,800 次 take6 实际出牌，12,800 次均与记录一致，没有浮点边界导致的不同抽样动作。',
        '- 比赛后再次核验冻结代码、权重及网页冠军身份，原模型索引的 70 个依赖文件检查通过。',
        f"- 协议 SHA-256：`{result['protocol_sha256']}`。",
        f"- 全部逐局轨迹 SHA-256：`{result['trace_sha256']}`。", '',
        '最终统计见 [results.json](../artifacts/take6-evaluation/results.json)，实际 take6 出牌审计见 [decision-audit.json](../artifacts/take6-evaluation/decision-audit.json)。', '']
    path = ROOT/'docs/TAKE6_EVALUATION.md'
    text = path.read_text(encoding='utf-8')
    start,end = text.index('## 5. 比赛结果'),text.index('## 6. 文件与复现')
    text = text[:start]+'\n'.join(lines)+'\n'+text[end:]
    text = text.replace('测试日期：2026-09-15。完整比赛进行中，以下为已冻结的方法；成绩仅在全部 1,280 局及回放审计完成后填写。',
        '测试日期：2026-09-15。1,280 局固定规模比赛及全部回放审计已完成；下文记录作者原始权重的适配、协议、结果与限制。')
    text = text.replace('逐局动作会独立重放：','逐局动作已独立重放：')
    path.write_text(text,encoding='utf-8')
    path = ROOT/'docs/TECHNICAL_REPORT.md'
    text = path.read_text(encoding='utf-8')
    text = text.replace('已接入的外部方法只有部分开源策略及论文的本地复现，尚未覆盖全部公开预训练模型；没有闭源原版系统的实测结果。',
        '已接入部分开源策略、论文的本地复现，以及 take6 作者发布的二人／四人原始预训练权重；尚未覆盖全部公开模型，没有闭源原版系统的实测结果。')
    text = text.replace('1,280 局固定规模测试正在运行；包含四人主比较、选行规则敏感性和二人原生／迁移场景。',
        '1,280 局固定规模比赛、计分回放及全部 12,800 次 take6 出牌核验已完成；结果见下表。')
    heading = '#### take6 作者原始权重的新增实测'
    end_heading = '#### 当前冠军与三种已接入外部方法的同桌比分'
    section = [heading, '', '本次新增 1,280 局，采用作者原始权重的 FP32 推理移植和默认概率抽样，没有重训 take6。', '']
    section += comparison_table(summaries)
    section += ['', conclusion,
        '四人主比较为 512 局 / 128 组发牌；规则敏感性为复用其中 64 组的 256 局；两种二人场景各为 256 局 / 128 组。区间按完整发牌组 bootstrap，补充场景不作多重比较校正。', '',
        '二人 24 张对应 take6 专家模型的原生牌池，对手是网页兼容策略；二人 104 张对手为 V6，对 take6 属于迁移。四人同桌另有 DirV 和 MCS，且双方推理预算不同，不能把结果解释为等算力排名或对所有外部模型的胜率。', '',
        '详细规则、各模型牛头数、时延口径、原始文件、12,800 次实际出牌的一致性审计及复现命令见 [take6 专项报告](TAKE6_EVALUATION.md)。本轮没有改动网页模型或原正式升级证书。', '']
    if heading in text:
        start = text.index(heading)
        text = text[:start]+text[text.index(end_heading,start):]
    text = text.replace(end_heading,'\n'.join(section)+'\n'+end_heading)
    path.write_text(text,encoding='utf-8')
    print(json.dumps(dict(status='reported', conclusion=conclusion, games=1280)))


if __name__ == '__main__':
    main()
